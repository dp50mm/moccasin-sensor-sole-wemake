2014-01-10

* spellcheck CG1G2G1G2.
* checked the glide reflection of TCCTGG. added NOTES to TCCTGG about how it is constructed. added a dash line AD.
* checked the glide reflection of TCTGG. added NOTES to TCTGG about how it is constructed.
* checked the glide reflection of CCGG. added NOTES to CGG about how it is constructed.

2014-01-09

* updated the oogway library, added distance(oogway), towards(oogway) and angleBetween(oogway).
* added a function in math.pde to calculate the intersection between two lines.
* added NOTES to CGG about how it is constructed.

2014-01-08

* updated README.MD with the new commands such as pathForward, pathBackward, dashForward, dashBackward, shift, shiftForward, shiftBackward, shiftLeft, shiftRight etc.
* added NOTES to TG1G1G2G2 about how it is constructed. Updated the way that H1I1 and H2I2 are drawn.
* added NOTES to TGTG about how it is constructed.

2014-01-07

* renamed CG1CG2G1G2_STEP TO CG1CG2G1G2i in tessellation examples.
* combined methods for triangulation into math.pde.
* combined drawInfo drawAxes, drawArrow, drawPoints and hightlightGroup into annotation.pde
* changed the position of the highlighed Group into the first group in tessellation.
* moved svg files into data folder
* added NOTES to G1G1G2G2 about how it is constructed. Updated the way that H1I1 and H2I2 are drawn.